﻿Public Class Form1

    'rename this, doesn't make sense
    Dim media As Media = New Media
    'rename this, doesn't make sense
    Dim user As Admin = New Admin

    Private Sub SubmitButton_Click(sender As Object, e As EventArgs) Handles SearchMediaSubmitButton.Click
        SearchReturnText.Clear()
        SearchReturnText.Text = media.searchMedia(SearchTypeDrop.Text, SearchText.Text)
    End Sub

    Private Sub UseNamePassSubmit_Click(sender As Object, e As EventArgs) Handles SignInButton.Click
        user.SignIn(UserNameText.Text, PassWordText.Text)
        If user.AdminAproved() Then
            Panel1.Visible = True
        End If
        UserInfo.Text = user.PrintUserInfo()
        Rentals.Text = user.PrintUserRentals()
        UserNameText.Clear()
        PassWordText.Clear()
    End Sub

    Private Sub AddUserInformation_Click(sender As Object, e As EventArgs) Handles AddUserInformation.Click
        user.addUser(AddNameText.Text, AddPasswordText.Text, IsUserAdmin.Text, AddAddressText.Text,
                          DateTimePicker1.Text, AddEmailText.Text, AddPhoneText.Text,
                          AddFirstNameText.Text, AddLastNameText.Text)
        AddNameText.Clear()
        AddPasswordText.Clear()
        IsUserAdmin.Text = "False"
        AddAddressText.Clear()
        AddEmailText.Clear()
        AddPhoneText.Clear()
        AddFirstNameText.Clear()
        AddLastNameText.Clear()
    End Sub

    Private Sub UserLookUpSearchButton_Click(sender As Object, e As EventArgs) Handles UserLookUpSearchButton.Click
        If Not IsNumeric(LookUpUserLastNameText.Text) Then
            MsgBox("Please only enter ID numbers")
            Exit Sub
        End If
        UserLookUpInfoBox.Text = user.UserLookUp(LookUpUserLastNameText.Text)
    End Sub

    Private Sub DeleteUserFromSystem_Click(sender As Object, e As EventArgs) Handles DeleteUserFromSystem.Click
        user.deleteUser()
        UserLookUpInfoBox.Clear()
    End Sub

    Private Sub CheckOut_Click(sender As Object, e As EventArgs) Handles CheckOut.Click
        If Not IsNumeric(CheckOutMediaID.Text) And Not IsNumeric(CheckOutUserID.Text) Then
            MsgBox("Please only enter ID numbers")
            Exit Sub
        End If
        media.CheckOutMedia(CInt(CheckOutMediaID.Text), CInt(CheckOutUserID.Text))
        CheckOutMediaID.Clear()
        CheckOutUserID.Clear()
    End Sub

    Private Sub CheckIn_Click(sender As Object, e As EventArgs) Handles CheckIn.Click
        If Not IsNumeric(CheckInMediaID.Text) Then
            MsgBox("Please only enter ID numbers")
            Exit Sub
        End If
        media.CheckInMedia(CInt(CheckInMediaID.Text))
        CheckInMediaID.Clear()
    End Sub

    Private Sub FinePaidButton_Click(sender As Object, e As EventArgs) Handles FinePaidButton.Click
        If Not IsNumeric(FinePaidText.Text) Then
            MsgBox("Please only enter ID numbers")
            Exit Sub
        End If
        media.deletefines(CInt(FinePaidText.Text))
    End Sub

    Private Sub SignOutButton_Click(sender As Object, e As EventArgs) Handles SignOutButton.Click
        UserInfo.Clear()
        Rentals.Clear()
        UserNameText.Clear()
        PassWordText.Clear()
    End Sub
End Class
