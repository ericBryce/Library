﻿Public Class Form1

    Protected media As Media = New Media
    Protected user As Admin = New Admin

    Private Sub SearchMediaSubmitButton_Click(sender As Object, e As EventArgs) Handles SearchMediaSubmitButton.Click
        SearchReturnText.Clear()
        Dim searchType, search As String
        searchType = SearchTypeDrop.Text
        search = SearchText.Text
        SearchReturnText.Text = media.searchMedia(searchType, search)
    End Sub

    Private Sub UserSignIn_Click(sender As Object, e As EventArgs) Handles UserSignIn.Click
        Dim userName As String
        Dim password As String
        userName = UserNameText.Text
        password = PassWordText.Text
        user.SignIn(userName, password)
        If user.AdminAproved() Then
            Panel1.Visible = True
        End If
        UserInfo.Text = user.PrintUserInfo()
        Rentals.Text = user.PrintUserRentals()
    End Sub

    'add checks for empty fields
    Private Sub AddUserInformation_Click(sender As Object, e As EventArgs) Handles AddUserInformation.Click
        user.addUser(AddNameText.Text, AddPasswordText.Text, IsUserAdmin.Text, AddAddressText.Text,
                          DateTimePicker1.Text, AddEmailText.Text, AddPhoneText.Text,
                          AddFirstNameText.Text, AddLastNameText.Text)
        AddNameText.Clear()
        AddPasswordText.Clear()
        IsUserAdmin.Text = "False"
        AddAddressText.Clear()
        AddEmailText.Clear()
        AddPhoneText.Clear()
        AddFirstNameText.Clear()
        AddLastNameText.Clear()
    End Sub

    'checks need to be put in to make sure numeric parameters passed
    Private Sub UserLookUpSearchButton_Click(sender As Object, e As EventArgs) Handles UserLookUpSearchButton.Click
        If IsNumeric(LookUpUserLastNameText.Text) Then
            UserLookUpInfoBox.Text = user.UserLookUp(LookUpUserLastNameText.Text)
        Else : MsgBox("Please only enter user Id's in this field")
        End If

    End Sub

    Private Sub DeleteUserFromSystem_Click(sender As Object, e As EventArgs) Handles DeleteUserFromSystem.Click
        user.deleteUser()
    End Sub

    Private Sub CheckOut_Click(sender As Object, e As EventArgs) Handles CheckOut.Click
        media.CheckOutMedia(CheckOutMediaID.Text, CheckOutUserID.Text)
    End Sub

    Private Sub CheckIn_Click(sender As Object, e As EventArgs) Handles CheckIn.Click
        media.CheckInMedia(CheckInMediaID.Text)
    End Sub
    Private Sub DeleteFineButton_Click(sender As Object, e As EventArgs) Handles DeleteFineButton.Click
        media.deletefines(DeleteFineText.Text)
    End Sub
End Class
