﻿Public Class Fines
    Dim checkOutMonth As Integer
    Dim checkOutDay As Integer
    Dim checkoutYear As Integer
    Dim monthDue As Integer
    Dim dayDue As Integer
    Dim yearDue As Integer
    Dim fine As Double

    'uses current system date for check out date
    Function mediaCheckedout() As String
        checkOutMonth = Date.Now.Month
        checkOutDay = Date.Now.Day
        checkoutYear = Date.Now.Year
        Return checkOutMonth & "/" & checkOutDay & "/" & checkoutYear
    End Function

    'assings due date, checks for end of month and year
    Function DueDate() As String
        If checkOutMonth < 12 Then
            monthDue = checkOutMonth + 1
        Else
            monthDue = 1
            yearDue = checkoutYear + 1
        End If

        If checkOutDay > 30 Then
            dayDue = 29
        Else : dayDue = checkOutDay
        End If

        Return monthDue & "/" & dayDue & "/" & yearDue
    End Function

    Function IsLate() As Boolean
        'gives user 1 month to return
        'also takes into account end of month, year will be mandatory purchase of book
        If checkOutMonth = 12 And Date.Now.Month > 1 Then
            Return True
        ElseIf monthDue > Date.Now.Month Then
            Return True
        End If
        Return False
    End Function

    Function GetFines() As Double
        Dim monthsLate As Integer = 0
        Dim daysLate As Integer = 0
        If IsLate() Then
            'if book is passed due going into a new month
            If monthDue < Date.Now.Month Then
                monthDue = monthDue - 12
            End If
            monthsLate = Date.Now.Month - monthDue

            If dayDue < Date.Now.Day Then
                daysLate = Date.Now.Day
            End If
            daysLate = Date.Now.Day - dayDue
        End If
        'charges are calculated by month(if has been more than 1 month) and then day
        fine = monthsLate * 1.5 + daysLate * 0.05
        Return fine
    End Function
End Class
