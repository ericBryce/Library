﻿Imports Excel = Microsoft.Office.Interop.Excel
Public Class Media
    'opens exell, and creates workbook and worksheet objects
    Dim APP As New Excel.Application
    Dim worksheetMedia As Excel.Worksheet
    Dim workbookMedia As Excel.Workbook
    Dim mediaRowHeight As Integer
    Dim dueDatesAndFines As Fines = New Fines

    Sub New()
        'assigns preexisting media excel sheet to our objects, info passed in is a relative path to the sheets included in the project folder
        workbookMedia = APP.Workbooks.Open(IO.Path.Combine(IO.Directory.GetParent(Application.ExecutablePath).FullName, "media.xlsx"))
        worksheetMedia = workbookMedia.Worksheets("sheet1")
        'm2 is the cell where the size is kept in the worksheet
        mediaRowHeight = worksheetMedia.Range("M2").Value
    End Sub

    Function searchMedia(ByRef searchType As String, ByRef search As String) As String
        Dim currentCell As String
        Dim column As Integer
        'checks to make sure all fields are filled out
        If searchType = "Choose Option" Then
            MsgBox("Please select search type")
            Return ""
        End If

        If search = "" Then
            MsgBox("Please enter search criteria")
            Return ""
        End If

        If search.Length < 1 Then
            MsgBox("please enter at least 3 characters")
            Return ""
        End If

        'gives search option a more usable value
        If searchType = "Name" Then column = 1
        If searchType = "Author" Then column = 2
        If searchType = "Genre" Then column = 4

        'string builder is used to make output easier
        Dim builder As New System.Text.StringBuilder
        For row As Integer = 2 To mediaRowHeight
            currentCell = worksheetMedia.Cells(row, column).Value
            'substrings are used so searcher doesn't have to get the name exactly correct
            If search.Substring(0, 1).ToLower = currentCell.Substring(0, 1).ToLower Then
                Dim name As String = worksheetMedia.Range("A" & row).Value
                Dim author As String = worksheetMedia.Range("B" & row).Value
                Dim type As String = worksheetMedia.Range("C" & row).Value
                Dim genre As String = worksheetMedia.Range("D" & row).Value
                Dim loc As String = worksheetMedia.Range("F" & row).Value
                builder.Append(name & "     " & author & "       " & type & "      " &
                               "       " & genre & "      " & loc & vbNewLine)
            End If
        Next
        Return builder.ToString
    End Function

    Public Function findRentals(userId As Integer) As String
        'string builder used to make out easier
        Dim builder As New System.Text.StringBuilder
        For row As Integer = 2 To mediaRowHeight
            'searched for loaned to cell for user rentals and returns book info
            'adding book availabitly later
            If userId = worksheetMedia.Range("E" & row).Value Then
                builder.Append("Title: " & worksheetMedia.Range("A" & row).Value &
                               ",  Media ID: " & worksheetMedia.Range("G" & row).Value &
                               "  Due Date: " & worksheetMedia.Range("H" & row).Value & vbNewLine)
            End If
        Next
        Return builder.ToString
    End Function

    Sub CheckOutMedia(mediaID As String, userID As String)
        'check for null values
        If mediaID = "" Or userID = "" Then
            MsgBox("Please enter all fields")
            Exit Sub
        End If
        'if media value = -1(available) assigns user to that book and a due date
        If worksheetMedia.Range("E" & mediaID).Value = -1 Then
            worksheetMedia.Range("E" & mediaID).Value = userID
            dueDatesAndFines.mediaCheckedout()
            worksheetMedia.Range("H" & mediaID).Value = dueDatesAndFines.DueDate
            MsgBox("Checkout complete")
            SaveMediaDatabase()
        Else : MsgBox("Media already checked out")
        End If


    End Sub

    Sub CheckInMedia(mediaID As String)
        If mediaID = "" Then
            MsgBox("Please enter all fields")
            Exit Sub
        End If
        'resets value of book to -1(available
        worksheetMedia.Range("E" & mediaID).Value = -1
        SaveMediaDatabase()
    End Sub

    'these are called in the dispose(destructor) so changes are saved and the excel sheet closes when the program closes
    Sub SaveMediaDatabase()
        workbookMedia.Save()
    End Sub
    Sub CloseUserDatabase()
        workbookMedia.Close()
        APP.Quit()
    End Sub
End Class
